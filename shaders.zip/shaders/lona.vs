#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoords;

out vec2 TexCoords;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform float time; 
uniform int tipoViento; // 1 para Uniforme, 2 para Caótico

void main()
{
    vec3 pos = aPos;

    if(tipoViento == 1) {
        // --- VIENTO 1: ONDEADO UNIFORME (Arriba a abajo) ---
        float frecuencia = 4.0; 
        float amplitud = 0.3;
        pos.z += sin(pos.y * frecuencia + time) * amplitud;
    } 
    else if(tipoViento == 2) {
        // --- VIENTO 2: MOVIMIENTO CAÓTICO (Varias direcciones) ---
        // Mezclamos senos y cosenos con X y Y
        float movZ = sin(pos.x * 10.0 + time * 4.0) * cos(pos.y * 8.0 + time * 3.0);
        pos.z += movZ * 0.5;
        // Movimiento lateral extra
        pos.x += sin(time + pos.y) * 0.2;
    }

    gl_Position = projection * view * model * vec4(pos, 1.0);
    TexCoords = aTexCoords;
}